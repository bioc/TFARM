### R code from vignette source 'TFARM.Rnw'

###################################################
### code chunk number 1: style
###################################################
BiocStyle::latex()


###################################################
### code chunk number 2: options
###################################################
options(width=90)


###################################################
### code chunk number 3: preliminaries
###################################################
library(TFARM)


###################################################
### code chunk number 4: TFARM.Rnw:69-72
###################################################
data("MCF7_chr1")
dim(MCF7_chr1)
head(MCF7_chr1)


###################################################
### code chunk number 5: TFARM.Rnw:126-142
###################################################
# Coming back to the example on the transcription factors of cell line MCF7,
# in the promotorial regions of chromosome 1.
# Suppose that the user wants to find the most relevant association rules for the
# prediction of the presence of the transcription factor TEAD4 and such that the
# left-hand-side of the rules contains only present transcription factors.
# This means extracting all the association rules with right hand side equal to
# {TEAD4=1} setting the parameter type = TRUE; the minimun support and minimum
# confidence thresholds are set, as an example, to 0.005 and 0.62, respectively:

m <- dim(MCF7_chr1)[2]
r_TEAD4 <- rulesGen(MCF7_chr1[,2:m], "TEAD4=1", 0.005, 0.62, TRUE)

dim(r_TEAD4)

head(r_TEAD4)



###################################################
### code chunk number 6: TFARM.Rnw:159-174
###################################################
# Transcription factors present in at least one of the regions in the considered dataset:
c <- colnames(MCF7_chr1)[2:m]
c

m <- length(c)

names(presAbs(c, r_TEAD4, TRUE))

# Transcription factors present in at least one of the association rules:
p <- presAbs(c, r_TEAD4, TRUE)$pres
p

# Transcription factors absent in all the association rules:
a <- presAbs(c[2:m], r_TEAD4, TRUE)$abs
a


###################################################
### code chunk number 7: TFARM.Rnw:298-302
###################################################
# To find the subset of rules containing the transcription factor FOSL2:
r_FOSL2 <- rulesTF(TFi  = 'FOSL2=1', rules =  r_TEAD4, verbose = TRUE)
head(r_FOSL2)
dim(r_FOSL2)[1]


###################################################
### code chunk number 8: TFARM.Rnw:306-309
###################################################
# If none of the rules in input to rulesTF contains the given item TFi,
# and verbose = TRUE, a console message warns for an error:
r_CTCF <- rulesTF(TFi = 'CTCF=1', rules = r_TEAD4, verbose = TRUE)


###################################################
### code chunk number 9: TFARM.Rnw:322-329
###################################################
# For example to evaluate FOSL2 importance in the set of rules r_FOSL2:

r_noFOSL2 <- rulesNTF('FOSL2=1', r_FOSL2, r_TEAD4)
head(r_noFOSL2)

# Since none of the rules in r_FOSL2 has been found in the set of rules r_TEAD4
# once removed FOSL2, the three measures of all the obtained rules are set to zero.


###################################################
### code chunk number 10: IComp
###################################################
imp_FOSL2 <- IComp('FOSL2=1', r_FOSL2, r_noFOSL2, figures=TRUE)
names(imp_FOSL2)

imp_FOSL2$imp

head(imp_FOSL2$delta)


###################################################
### code chunk number 11: TFARM.Rnw:365-388
###################################################
# For the considered example the user could run:

library(plyr)

A <- list()
B <- list()
IMP <- matrix(0, length(p), 4)
IMP <- data.frame(IMP)
IMP[,1] <- paste(p)
colnames(IMP) <- c('TF', 'imp', 'sd', 'nrules')
IMP_Z <- list()

for (i in 1:length(p))  {
	A[[i]] <- rulesTF(p[i], r_TEAD4, FALSE)
	B[[i]] <- rulesNTF(p[i], A[[i]], r_TEAD4)
	IMP_Z[[i]] <- IComp(p[i], A[[i]], B[[i]], figures=FALSE)$imp
	IMP[i,2] <- mean(IMP_Z[[i]])
	IMP[i,3] <- sqrt(var(IMP_Z[[i]]))
	IMP[i,4] <- length(IMP_Z[[i]])
}

IMP.ord <- arrange(IMP, desc(imp))
IMP.ord


###################################################
### code chunk number 12: IPCA
###################################################
DELTA <- list()
for (i in 1:length(p)){
DELTA[[i]] <- IComp(p[i], A[[i]], B[[i]], figures=FALSE)$delta
}

colnames(IMP)
I <- data.frame(IMP$TF, IMP$imp, IMP$nrules)
i.pc <- IPCA(DELTA, I)
names(i.pc)

i.pc$summary

i.pc$loadings


###################################################
### code chunk number 13: distribViz
###################################################
# Considering for example the candidate co-regulator transcription factors
# found in the set of rules r_TEAD4
distribViz(IMP_Z,p)


###################################################
### code chunk number 14: TFARM.Rnw:496-516
###################################################
# Select the index of the list of importances IMP_Z
# containing importance distributions of transcription factor HDAC2
HDAC2_index <- which(p == 'HDAC2=1')

# select outlier rules where HDAC2 has importance greater than 5
o <- which(IMP_Z[[HDAC2_index]] > 5)
rule_o <- A[[HDAC2_index]][o,]
rule_o

# So, HDAC2 is very relevant in the pattern of transcription factors
# {FOSL2=1,HDAC2=1,GABPA=1,GATA3=1,MYC=1,ELF1=1,ZNF217=1}
# for the prediction of the presence of TEAD4.

# To extract support, confidence and lift of the correspondent rule without HDAC2:
B[[HDAC2_index]][o,]

# Since none of the three measures of the rule obtained removing HDAC2 are equal to zero,
# the rule {FOSL2=1,GABPA=1,GATA3=1,MYC=1,ELF1=1,ZNF217=1} -> {TEAD4=1} is
# obtained removing HDAC2, is found in the relevant rules for the prediction
# of the presence of TEAD4.


###################################################
### code chunk number 15: TFARM.Rnw:540-566
###################################################
couples_0 <- combn(p, 2)
couples <- apply(couples_0, 2, function(x){
	paste(x[1], x[2], sep=',')
})
head(couples)

# The evaluation of the mean importance of each couple is then computed as previously done
# for single transcription factors:

A_c <- list()
B_c <- list()
I_c <- matrix(0, length(couples), 2)
I_c <- data.frame(I_c)
I_c[,1] <- paste(couples)
colnames(I_c) <- c('TF', 'imp')
IMP_c <- list()
for (i in 1:length(couples))  {
	A_c[[i]] <- rulesTF(couples[i], r_TEAD4, FALSE)
	B_c[[i]] <- rulesNTF(couples[i], A_c[[i]], r_TEAD4)
	IMP_c[[i]] <- IComp(couples[i], A_c[[i]], B_c[[i]], figures=FALSE)$imp
	I_c[i,2] <- mean(IMP_c[[i]])
}

I_c <- I_c[which(!is.na(I_c[,2])),]
I_c_ord <- arrange(I_c, desc(imp))
head(I_c_ord)


###################################################
### code chunk number 16: heatmap
###################################################
I_c_2 <- arrange(rbind(IMP[,1:2], I_c_ord), desc(imp))
heatI(p, I_c_2)


